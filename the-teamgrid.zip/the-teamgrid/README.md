# The Team - Grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/andytran/pen/BKOOQy](https://codepen.io/andytran/pen/BKOOQy).

Designed by [@MarioMaruffi](https://dribbble.com/shots/2678953-Team-Grid) for [@ElegantThemes](https://www.elegantthemes.com) upcoming podcast!