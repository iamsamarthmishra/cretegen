# Dual Sliding Landing page

A Pen created on CodePen.io. Original URL: [https://codepen.io/andrewerrico/pen/xwRZeJ](https://codepen.io/andrewerrico/pen/xwRZeJ).

Quick idea for a dual career/portfolio landing page with css animations